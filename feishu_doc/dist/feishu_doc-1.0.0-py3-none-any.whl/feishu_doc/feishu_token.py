class FeishuToken:
    def __init__(self, app_token, personal_token):
        self.app_token = app_token
        self.personal_token = personal_token
